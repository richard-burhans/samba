/*
 * Minimal stand-in for Samba's lib/replace/replace.h, just enough to
 * build the winbind NSS client (wb_common.c, winbind_nss_linux.c,
 * winbind_nss_solaris.c) outside the Samba build system.
 */
#ifndef _MINI_REPLACE_H
#define _MINI_REPLACE_H

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <pwd.h>
#include <grp.h>
#include <pthread.h>

#define HAVE_PTHREAD 1
#define HAVE_PTHREAD_H 1

#ifndef _PUBLIC_
#define _PUBLIC_ __attribute__((visibility("default")))
#endif
#ifndef _PRIVATE_
#define _PRIVATE_ __attribute__((visibility("hidden")))
#endif
#ifndef _PUBLIC_ON_LINUX_
#define _PUBLIC_ON_LINUX_
#endif
#ifndef PRINTF_ATTRIBUTE
#define PRINTF_ATTRIBUTE(a, b) __attribute__((format(__printf__, a, b)))
#endif
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef ZERO_STRUCT
#define ZERO_STRUCT(x) memset((char *)&(x), 0, sizeof(x))
#endif
#ifndef ZERO_STRUCTP
#define ZERO_STRUCTP(x) do { if ((x) != NULL) memset((char *)(x), 0, sizeof(*(x))); } while (0)
#endif
#ifndef discard_const
#define discard_const(ptr) ((void *)((uintptr_t)(ptr)))
#endif
#ifndef discard_const_p
#define discard_const_p(type, ptr) ((type *)discard_const(ptr))
#endif
#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#endif

/*
 * Samba's replace.h probes for the cwrap test wrappers; a production
 * build never runs under them.
 */
static inline bool nss_wrapper_enabled(void) { return false; }
static inline bool uid_wrapper_enabled(void) { return false; }

#endif /* _MINI_REPLACE_H */
